<?php 
    class Basecontroller extends CI_Controller {
        function __contruct(){
            parent::__construct();
        }
        function login(){
            echo "hai";
        }
    }
?>