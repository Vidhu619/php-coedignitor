<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {


	public function index()
	{

		
		$this->load->view('Auth/login');
	}
	public function Register() 
    {
        
        $this->load->view('Auth/Register');
    }
	public function View() 
    {
        
        $this->load->view('Auth/View');
    }
	public function Registration_form() 
    {
        
        $this->auth_model->register_user();
    }
	public function login_form() 
    {
        
        $this->auth_model->login_user();
    }

}
