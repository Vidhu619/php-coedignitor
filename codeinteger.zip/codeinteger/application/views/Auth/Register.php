<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <title>Registration Form</title>
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          Register
        </div>
        <div class="card-body">
          <?php echo form_open('Auth/Registration_form');?>
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" name="name"class="form-control" id="name" placeholder="Enter your name">
            </div>
            <div class="form-group">
              <label for="email">Email address</label>
              <input type="email" name="email"class="form-control" id="email" placeholder="Enter your email">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="password"class="form-control" id="password" placeholder="Enter your password">
            </div>
            <div class="form-group">
              <label for="confirmPassword">Confirm Password</label>
              <input type="password" name="con_password"class="form-control" id="confirmPassword" placeholder="Confirm your password">
            </div>
            <button type="submit" class="btn btn-primary">Register</button>
        <?php echo form_close();?>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
  <?php if ($this->session->flashdata('suc')){?>
    toaster.success("<?php echo $this->session->flashdata('suc');?>");
  <?php } elseif($this->session->flashdata('wrong')) { ?>
    toaster.error("<?php echo $this->session->flashdata('wrong');?>");
  <?php } elseif($this->session->flashdata('warning')) { ?>
    toaster.warning("<?php echo $this->session->flashdata('warning');?>");
  <?php } elseif($this->session->flashdata('info')) { ?>
    toaster.info("<?php echo $this->session->flashdata('info');?>");
  <?php } ?>
  
  <?php $this->session->unset_userdata('suc');?>
  <?php $this->session->unset_userdata('wrong');?>
</script>

</body>
</html>
